# Online Doctor Appointment Booking System

Stack: React + Vite, Node.js + Express, MySQL.

## 1. Requirements
- Node.js and npm
- MySQL Server (and MySQL Workbench is helpful)
- VS Code

## 2. Database setup
1. Open MySQL Workbench and connect to your local MySQL server.
2. Open `database/schema.sql`.
3. Run the entire SQL script. It creates the `doctor_appointment` database and tables, then inserts sample doctors.

## 3. Configure backend
Open a VS Code terminal:
```powershell
cd "C:\fsd project\backend"
npm install
```
Copy `.env.example` to `.env` and update the MySQL username/password:
```env
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=YOUR_MYSQL_PASSWORD
DB_NAME=doctor_appointment
JWT_SECRET=replace_this_with_a_long_random_secret
```
Do not share or upload `.env` to GitHub.

Start backend:
```powershell
npm run dev
```
Test in browser: http://localhost:5000/api/health

## 4. Configure frontend
Open a SECOND terminal:
```powershell
cd "C:\fsd project\frontend"
npm install
```
Copy the files from this package's `frontend` folder into your existing `C:\fsd project\frontend` folder, replacing the starter `src` files and `package.json` if needed. Then run:
```powershell
npm run dev
```
Open the Local URL shown by Vite (often http://localhost:5173 or http://localhost:5174).

## 5. Features included
- Patient registration and login (passwords hashed with bcrypt)
- List/search doctors by name or specialization
- Book an appointment
- View the signed-in patient's appointments
- Cancel a patient's own appointment
- MySQL uniqueness constraint prevents two bookings for the same doctor/date/time slot

## Notes
- This is a learning/demo project, not a production-ready medical system.
- For real deployment, add stronger validation, rate limiting, HTTPS, email verification, secure cookie/token handling, audit logging, backups, and privacy/security review.
- The API currently allows any registered patient to view available doctors and manage their own appointments only.
