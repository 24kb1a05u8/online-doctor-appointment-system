import { useEffect, useMemo, useState } from "react";
import { Link, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import api from "./api";

function Header({ user, onLogout }) {
  return (
    <header className="header">
      <Link className="brand" to="/"><span className="brand-icon">✚</span> CarePoint</Link>
      <nav>
        <NavLink to="/">Home</NavLink>
        <NavLink to="/doctors">Find Doctors</NavLink>
        {user && <NavLink to="/appointments">My Appointments</NavLink>}
      </nav>
      <div className="header-actions">
        {user ? <><span className="welcome">Hi, {user.name.split(" ")[0]}</span><button className="btn btn-outline btn-small" onClick={onLogout}>Log out</button></> :
          <><Link className="login-link" to="/login">Log in</Link><Link className="btn btn-primary btn-small" to="/register">Sign up</Link></>}
      </div>
    </header>
  );
}

function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="pulse" /> HEALTHCARE, MADE SIMPLE</span>
          <h1>Your health deserves <span>better care.</span></h1>
          <p>Find trusted doctors, choose a convenient time, and book your appointment in a few simple steps.</p>
          <div className="hero-actions"><Link className="btn btn-primary" to="/doctors">Find a doctor <span>→</span></Link><Link className="btn btn-white" to="/register">Create an account</Link></div>
          <div className="hero-proof"><div className="avatar-stack"><i>DR</i><i>+</i><i>♥</i></div><span><strong>Care starts here</strong><small>Simple, convenient appointment booking</small></span></div>
        </div>
        <div className="hero-art" aria-label="Healthcare illustration">
          <div className="art-circle"></div><div className="art-card art-card-top"><span className="art-check">✓</span><span><b>Appointment booked</b><small>Your health comes first</small></span></div>
          <div className="doctor-illustration"><div className="doc-hair"></div><div className="doc-face"><div className="doc-eyes"></div><div className="doc-smile"></div></div><div className="doc-neck"></div><div className="doc-coat"><span>✚</span></div><div className="doc-stethoscope"></div></div>
          <div className="art-card art-card-bottom"><span className="heart">♡</span><span><b>Care you can trust</b><small>One step at a time</small></span></div>
          <div className="sparkle sparkle-one">✦</div><div className="sparkle sparkle-two">✦</div>
        </div>
      </section>
      <section className="benefits">
        <div><span className="benefit-icon mint">⌕</span><div><b>Find the right doctor</b><p>Explore doctors by specialty.</p></div></div>
        <div><span className="benefit-icon lavender">▦</span><div><b>Book with ease</b><p>Choose a date and time.</p></div></div>
        <div><span className="benefit-icon peach">♡</span><div><b>Manage your visits</b><p>Keep appointments in one place.</p></div></div>
      </section>
      <section className="cta"><div><span className="eyebrow">TAKE THE FIRST STEP</span><h2>Ready to put your health first?</h2><p>Find a doctor and book your visit today.</p></div><Link to="/doctors" className="btn btn-primary">Explore doctors →</Link></section>
      <footer>© {new Date().getFullYear()} CarePoint. Your health, our priority.</footer>
    </main>
  );
}

function Doctors({ user }) {
  const [doctors, setDoctors] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("09:00");
  const [reason, setReason] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  async function loadDoctors(term = "") {
    try {
      const { data } = await api.get("/doctors", { params: { search: term } });
      setDoctors(data);
      setError("");
    } catch (e) {
      setError(e.response?.data?.message || "Could not load doctors. Make sure the backend and MySQL are running.");
    }
  }
  useEffect(() => { loadDoctors(); }, []);
  useEffect(() => {
    const timer = setTimeout(() => loadDoctors(search), 250);
    return () => clearTimeout(timer);
  }, [search]);

  async function book(event) {
    event.preventDefault();
    if (!user) { navigate("/login"); return; }
    setBusy(true); setMessage("");
    try {
      const { data } = await api.post("/appointments", {
        doctor_id: selected.id, appointment_date: date, appointment_time: time, reason
      });
      setMessage(data.message);
      setSelected(null); setDate(""); setReason("");
    } catch (e) {
      setMessage(e.response?.data?.message || "Booking failed. Please try again.");
    } finally { setBusy(false); }
  }

  return <main className="page">
    <div className="page-heading"><span className="eyebrow">YOUR HEALTH, YOUR CHOICE</span><h1>Find your doctor</h1><p>Browse our care team and choose the specialist who is right for you.</p></div>
    <div className="search-box"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by doctor or specialty..." aria-label="Search doctors" /></div>
    {error && <div className="alert error">{error}</div>}
    {message && <div className="alert">{message}</div>}
    <div className="doctor-grid">{doctors.map((doctor, i) => <article className="doctor-card" key={doctor.id}>
      <div className={`doctor-avatar avatar-${i % 4}`}><span>Dr</span></div><span className="specialty-tag">{doctor.specialization}</span>
      <h3>{doctor.name}</h3><p className="qualification">{doctor.qualification || "Qualified medical professional"}</p>
      <div className="doctor-meta"><span>◷ {doctor.experience_years} years experience</span><strong>₹{Number(doctor.consultation_fee).toFixed(0)}</strong></div>
      <button className="btn btn-primary full" onClick={() => { if (!user) { navigate("/login"); return; } setSelected(doctor); setMessage(""); }}>Book appointment</button>
    </article>)}</div>
    {!error && doctors.length === 0 && <div className="empty-state">No doctors found. Try another search.</div>}
    {selected && <div className="modal-backdrop" onClick={() => setSelected(null)}><section className="modal" onClick={e => e.stopPropagation()}>
      <button className="modal-close" onClick={() => setSelected(null)} aria-label="Close">×</button><span className="eyebrow">BOOK A VISIT</span><h2>{selected.name}</h2><p className="muted">{selected.specialization} · ₹{Number(selected.consultation_fee).toFixed(0)} consultation</p>
      <form className="form" onSubmit={book}><label>Appointment date<input required type="date" min={new Date().toLocaleDateString("en-CA")} value={date} onChange={e => setDate(e.target.value)} /></label><label>Preferred time<select value={time} onChange={e => setTime(e.target.value)}>{["09:00","09:30","10:00","10:30","11:00","11:30","12:00","14:00","14:30","15:00","15:30","16:00"].map(t => <option key={t} value={t}>{t}</option>)}</select></label><label>Reason for visit (optional)<textarea rows="3" maxLength="500" value={reason} onChange={e => setReason(e.target.value)} placeholder="Briefly describe your concern" /></label><button disabled={busy} className="btn btn-primary full">{busy ? "Booking..." : "Confirm appointment"}</button></form>
    </section></div>}
  </main>;
}

function AuthPage({ mode, onAuth }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  async function submit(event) {
    event.preventDefault(); setError(""); setBusy(true);
    try {
      const { data } = await api.post(`/auth/${mode}`, mode === "register" ? { name, email, password } : { email, password });
      onAuth(data); navigate("/doctors");
    } catch (e) { setError(e.response?.data?.message || "Could not connect to the server. Make sure the backend is running."); }
    finally { setBusy(false); }
  }
  return <main className="auth-layout"><section className="auth-aside"><div className="auth-aside-mark">✚</div><span className="eyebrow">WELCOME TO CAREPOINT</span><h2>Small steps today.<br />Healthier tomorrows.</h2><p>Your healthcare journey, organized in one simple place.</p><div className="aside-decoration">♡</div></section><section className="auth-main"><div className="auth-card"><span className="eyebrow">{mode === "login" ? "WELCOME BACK" : "GET STARTED"}</span><h1>{mode === "login" ? "Log in to CarePoint" : "Create your account"}</h1><p className="muted">{mode === "login" ? "Enter your details to access your appointments." : "Sign up to find doctors and book appointments."}</p>
    {error && <div className="alert error">{error}</div>}
    <form className="form" onSubmit={submit}>{mode === "register" && <label>Full name<input required autoComplete="name" value={name} onChange={e => setName(e.target.value)} placeholder="Your full name" /></label>}<label>Email address<input required type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" /></label><label>Password<input required minLength="8" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" /></label><button disabled={busy} className="btn btn-primary full">{busy ? "Please wait..." : mode === "login" ? "Log in" : "Create account"}</button></form>
    <p className="auth-switch">{mode === "login" ? "New to CarePoint?" : "Already have an account?"} <Link to={mode === "login" ? "/register" : "/login"}>{mode === "login" ? "Create an account" : "Log in"}</Link></p>
  </div></section></main>;
}

function Appointments({ user }) {
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  async function load() {
    setLoading(true);
    try { const { data } = await api.get("/appointments"); setAppointments(data); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Could not load appointments."); }
    finally { setLoading(false); }
  }
  useEffect(() => { if (!user) navigate("/login"); else load(); }, [user]);
  async function cancel(id) {
    if (!window.confirm("Cancel this appointment?")) return;
    try { const { data } = await api.patch(`/appointments/${id}/cancel`); setNotice(data.message); load(); }
    catch (e) { setError(e.response?.data?.message || "Could not cancel appointment."); }
  }
  const sorted = useMemo(() => appointments, [appointments]);
  return <main className="page"><div className="page-heading"><span className="eyebrow">YOUR CARE, IN ONE PLACE</span><h1>My appointments</h1><p>Review your upcoming and previous visits.</p></div>
    {notice && <div className="alert">{notice}</div>}{error && <div className="alert error">{error}</div>}
    {loading ? <p>Loading appointments...</p> : sorted.length === 0 ? <div className="empty-state"><div className="empty-icon">▦</div><h3>No appointments yet</h3><p>When you book a doctor, your visits will appear here.</p><Link className="btn btn-primary" to="/doctors">Find a doctor</Link></div> :
      <div className="appointment-list">{sorted.map(a => <article className="appointment-card" key={a.id}><div className="appointment-date"><b>{new Date(`${String(a.appointment_date).slice(0,10)}T12:00:00`).toLocaleDateString("en", { day:"2-digit" })}</b><span>{new Date(`${String(a.appointment_date).slice(0,10)}T12:00:00`).toLocaleDateString("en", { month:"short" })}</span></div><div className="appointment-info"><h3>{a.doctor_name}</h3><p>{a.specialization}</p><span>▦ {String(a.appointment_date).slice(0,10)} · {String(a.appointment_time).slice(0,5)}</span>{a.reason && <p className="muted">Reason: {a.reason}</p>}</div><div className="appointment-actions"><span className={`status status-${a.status}`}>{a.status}</span>{["booked","confirmed"].includes(a.status) && <button className="btn btn-outline btn-small" onClick={() => cancel(a.id)}>Cancel</button>}</div></article>)}</div>}
  </main>;
}

export default function App() {
  const [auth, setAuth] = useState(() => {
    const token = localStorage.getItem("carepoint_token");
    const raw = localStorage.getItem("carepoint_user");
    if (token && raw) { try { return { token, user: JSON.parse(raw) }; } catch { /* invalid saved user */ } }
    return null;
  });
  function onAuth(data) {
    localStorage.setItem("carepoint_token", data.token);
    localStorage.setItem("carepoint_user", JSON.stringify(data.user));
    setAuth({ token: data.token, user: data.user });
  }
  function logout() {
    localStorage.removeItem("carepoint_token");
    localStorage.removeItem("carepoint_user");
    setAuth(null);
  }
  const user = auth?.user || null;
  return <><Header user={user} onLogout={logout} /><Routes>
    <Route path="/" element={<Home />} />
    <Route path="/doctors" element={<Doctors user={user} />} />
    <Route path="/login" element={<AuthPage mode="login" onAuth={onAuth} />} />
    <Route path="/register" element={<AuthPage mode="register" onAuth={onAuth} />} />
    <Route path="/appointments" element={<Appointments user={user} />} />
    <Route path="*" element={<main className="page empty-state"><h1>Page not found</h1><Link to="/">Return home</Link></main>} />
  </Routes></>;
}
