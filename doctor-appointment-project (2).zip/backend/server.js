require("dotenv").config();

const express = require("express");
const cors = require("cors");
const db = require("./db");
const authRoutes = require("./routes/auth");
const doctorRoutes = require("./routes/doctors");
const appointmentRoutes = require("./routes/appointments");

if (!process.env.JWT_SECRET) {
  console.error("Missing JWT_SECRET. Create backend/.env using .env.example.");
  process.exit(1);
}

const app = express();
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || "http://localhost:5173" }));
app.use(express.json());

app.get("/api/health", async (req, res) => {
  try {
    await db.query("SELECT 1");
    res.json({ status: "ok", message: "Doctor Appointment API and database are running." });
  } catch (error) {
    res.status(503).json({ status: "error", message: "API is running but the database connection failed. Check backend/.env and MySQL." });
  }
});

app.use("/api/auth", authRoutes);
app.use("/api/doctors", doctorRoutes);
app.use("/api/appointments", appointmentRoutes);

app.use((req, res) => res.status(404).json({ message: "API route not found." }));

const port = Number(process.env.PORT || 5000);
app.listen(port, () => console.log(`Backend running at http://localhost:${port}`));
