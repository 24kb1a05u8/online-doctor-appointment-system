const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");

const router = express.Router();

router.post("/register", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (!name || !email || password.length < 8) {
      return res.status(400).json({ message: "Enter your name, a valid email, and a password with at least 8 characters." });
    }

    const [existing] = await db.execute("SELECT id FROM users WHERE email = ?", [email]);
    if (existing.length) {
      return res.status(409).json({ message: "An account with this email already exists." });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const [result] = await db.execute(
      "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
      [name, email, passwordHash]
    );

    const user = { id: result.insertId, name, email, role: "patient" };
    const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: "8h" });
    res.status(201).json({ message: "Account created successfully.", token, user });
  } catch (error) {
    console.error("Register error:", error.message);
    res.status(500).json({ message: "Could not create account. Check the backend and database setup." });
  }
});

router.post("/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const [rows] = await db.execute(
      "SELECT id, name, email, password_hash, role FROM users WHERE email = ?",
      [email]
    );

    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash))) {
      return res.status(401).json({ message: "Email or password is incorrect." });
    }

    const row = rows[0];
    const user = { id: row.id, name: row.name, email: row.email, role: row.role };
    const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: "8h" });
    res.json({ message: "Login successful.", token, user });
  } catch (error) {
    console.error("Login error:", error.message);
    res.status(500).json({ message: "Could not log in. Check the backend and database setup." });
  }
});

module.exports = router;
