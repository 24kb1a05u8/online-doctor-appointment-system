const express = require("express");
const db = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT a.id, a.appointment_date, a.appointment_time, a.reason, a.status,
              d.name AS doctor_name, d.specialization, d.consultation_fee
       FROM appointments a
       JOIN doctors d ON d.id = a.doctor_id
       WHERE a.patient_id = ?
       ORDER BY a.appointment_date DESC, a.appointment_time DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (error) {
    console.error("Appointments list error:", error.message);
    res.status(500).json({ message: "Could not load appointments." });
  }
});

router.post("/", async (req, res) => {
  try {
    const doctorId = Number(req.body.doctor_id);
    const date = String(req.body.appointment_date || "");
    const time = String(req.body.appointment_time || "");
    const reason = String(req.body.reason || "").trim().slice(0, 500);

    if (!Number.isInteger(doctorId) || doctorId < 1 || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) {
      return res.status(400).json({ message: "Choose a doctor, valid date, and time." });
    }
    if (date < new Date().toISOString().slice(0, 10)) {
      return res.status(400).json({ message: "Please choose today or a future date." });
    }

    const [doctors] = await db.execute("SELECT id FROM doctors WHERE id = ? AND available = TRUE", [doctorId]);
    if (!doctors.length) return res.status(404).json({ message: "Doctor not found or unavailable." });

    const [result] = await db.execute(
      `INSERT INTO appointments
       (patient_id, doctor_id, appointment_date, appointment_time, reason)
       VALUES (?, ?, ?, ?, ?)`,
      [req.user.id, doctorId, date, `${time}:00`, reason || null]
    );
    res.status(201).json({ message: "Appointment booked successfully.", id: result.insertId });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "That doctor already has an appointment at this date and time. Please choose another slot." });
    }
    console.error("Appointment booking error:", error.message);
    res.status(500).json({ message: "Could not book appointment." });
  }
});

router.patch("/:id/cancel", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [result] = await db.execute(
      `UPDATE appointments SET status = 'cancelled'
       WHERE id = ? AND patient_id = ? AND status IN ('booked', 'confirmed')`,
      [id, req.user.id]
    );
    if (!result.affectedRows) {
      return res.status(404).json({ message: "Appointment not found or cannot be cancelled." });
    }
    res.json({ message: "Appointment cancelled." });
  } catch (error) {
    console.error("Cancel appointment error:", error.message);
    res.status(500).json({ message: "Could not cancel appointment." });
  }
});

module.exports = router;
