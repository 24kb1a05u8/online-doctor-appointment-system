const express = require("express");
const db = require("../db");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const search = `%${String(req.query.search || "").trim()}%`;
    const [doctors] = await db.execute(
      `SELECT id, name, specialization, qualification, experience_years,
              consultation_fee, available
       FROM doctors
       WHERE available = TRUE AND (name LIKE ? OR specialization LIKE ?)
       ORDER BY name`,
      [search, search]
    );
    res.json(doctors);
  } catch (error) {
    console.error("Doctors error:", error.message);
    res.status(500).json({ message: "Could not load doctors. Check the database connection." });
  }
});

module.exports = router;
