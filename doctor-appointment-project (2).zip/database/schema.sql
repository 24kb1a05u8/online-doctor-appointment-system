CREATE DATABASE IF NOT EXISTS doctor_appointment
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE doctor_appointment;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('patient', 'admin') NOT NULL DEFAULT 'patient',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL,
  qualification VARCHAR(150),
  experience_years INT NOT NULL DEFAULT 0,
  consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  available BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  reason VARCHAR(500),
  status ENUM('booked', 'confirmed', 'completed', 'cancelled') NOT NULL DEFAULT 'booked',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_appointment_patient FOREIGN KEY (patient_id) REFERENCES users(id),
  CONSTRAINT fk_appointment_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id),
  CONSTRAINT unique_doctor_slot UNIQUE (doctor_id, appointment_date, appointment_time)
);

INSERT INTO doctors (name, specialization, qualification, experience_years, consultation_fee)
SELECT 'Dr. Ananya Rao', 'Cardiologist', 'MBBS, MD Cardiology', 12, 600
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE name = 'Dr. Ananya Rao');

INSERT INTO doctors (name, specialization, qualification, experience_years, consultation_fee)
SELECT 'Dr. Rahul Sharma', 'Dermatologist', 'MBBS, MD Dermatology', 8, 450
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE name = 'Dr. Rahul Sharma');

INSERT INTO doctors (name, specialization, qualification, experience_years, consultation_fee)
SELECT 'Dr. Priya Reddy', 'Pediatrician', 'MBBS, DCH', 10, 500
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE name = 'Dr. Priya Reddy');

INSERT INTO doctors (name, specialization, qualification, experience_years, consultation_fee)
SELECT 'Dr. Arjun Kumar', 'General Physician', 'MBBS', 6, 300
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE name = 'Dr. Arjun Kumar');

INSERT INTO doctors (name, specialization, qualification, experience_years, consultation_fee)
SELECT 'Dr. Meera Iyer', 'Neurologist', 'MBBS, DM Neurology', 15, 800
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE name = 'Dr. Meera Iyer');
